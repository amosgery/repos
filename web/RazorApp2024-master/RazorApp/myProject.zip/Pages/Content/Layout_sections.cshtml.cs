using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorApp.Pages.Content
{
    public class Layout_sectionsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
