using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorApp.Pages.Content
{
    public class testModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
