using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorApp.Pages.JavaScript
{
    public class InteractionWithHTMLModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
