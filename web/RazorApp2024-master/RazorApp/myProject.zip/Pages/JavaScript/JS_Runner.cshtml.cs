using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorApp.Pages.JavaScript
{
    public class JS_RunnerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
