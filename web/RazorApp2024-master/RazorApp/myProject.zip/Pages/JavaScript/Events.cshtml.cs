using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorApp.Pages.JavaScript
{
    public class EventsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
