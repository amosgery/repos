﻿
var a, b, c;
a = parseInt(prompt("Enter first number"));
b = parseInt(prompt("Enter second number"));
c = a + b;
document.writeln(c);
document.write("<br>");

for (var i = 1; i < 10; i++) {
    document.write(i);
}
