﻿
var str = "Gilad Markman born in 1968";
var s = str.slice(6, 13);
alert(s);

str = "     Gilad M     ";
s = str.trim();
alert(s.length);

document.write(str + "<br/>");
document.write(str.length + "<br/>");
document.write(str.charAt(0) + "<br/>");
document.write(str.charAt(str.length - 1));

var ch1 = str[i];
var ch2 = str.charAt(i);

str = str1 + "Shalom" + str2;