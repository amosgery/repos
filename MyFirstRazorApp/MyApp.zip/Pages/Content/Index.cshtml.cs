using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyFirstRazorApp.Pages.Content
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
